function setup() {
  createCanvas(400, 400);
  angleMode(DEGREES);
}

function draw() {
  background("rgb(143,143,219)");
  noStroke();
  fill("rgb(255,226,177)");
  rect(0,300,400,100);
  fill("orange");
  ellipse(100,50,60,30);
  triangle(120,50,140,70,140,30);
  fill("rgb(33,190,33)");
  ellipse(300,200,100,60);
  triangle(280,200,230,170,230,230);
  fill("white");
  ellipse(90,45,10);
  ellipse(330,195,20);
  fill("black");
  ellipse(89,46,3);
  ellipse(332,193,10);
  fill("darkgreen");
  triangle(300,197,300,220,315,203);
  fill("rgb(199,111,4)");
  triangle(100,47,100,60,115,56);
  noFill();
  stroke("black");
  arc(80,50,30,20,0,100);
  arc(340,210,30,20,90,180);
  fill("rgb(19,170,19)");
  noStroke();
  rect(100,200,10,100);
  rect(115,220,10,80);
  rect(130,180,10,120);
  fill("rgb(212,212,231)");
  ellipse(300,100,50);
  ellipse(320,50,30);
  ellipse(280,20,20);
  fill("white")
  ellipse(308,88,10);
  ellipse(325,45,5);
  ellipse(283,17,3);
  
}